package com.webiste.project.service;

import com.webiste.project.model.Cart;
import com.webiste.project.repository.CartRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class CartService {

    @Autowired
    CartRepo cao;
    public List<Cart> viewcart(int id) {
       return cao.findAllById(id);
    }

    public void addCart(Cart c) {
        cao.save(c);
    }

    @Transactional
    public void removeCart(int cid) {
    cao.deleteByCid(cid);
    }
}
