package com.webiste.project.controller;

import com.webiste.project.model.User;
import com.webiste.project.model.Vehical;
import com.webiste.project.service.VehicleService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@Controller
public class VehicalsController {

    @Autowired
    VehicleService vs;

    @GetMapping("/vehicals")
    String allVehicals(Model m, HttpSession s)
    {
        User u=(User)s.getAttribute("user");
        List<Vehical> veh=vs.findAll();
        System.out.println(veh.get(0).getVname());
        if(u!=null)
        {
            m.addAttribute("role", Arrays.asList(u.getRoles().split(",")));
        }
        m.addAttribute("vehicals", veh);
        return "vehicals";
    }

    @GetMapping("/view/{id}")
    String viewVehicle(@PathVariable("id")int id, Model p)
    {
        p.addAttribute("vehdet",vs.getVehicle(id));
        Vehical v= vs.getVehicle(id);
        //System.out.println(v.getVbrand());
        return "viewvehicle";
    }

    @GetMapping("/addvehicle")
    String addVehicle(Model m)
    {
        return "addvehicle";
    }

    @PostMapping("/addvehicle")
    String addVehicleform(@ModelAttribute("v")Vehical v)
    {
        vs.addVehical(v);
        System.out.println(v);
        return "redirect:/vehicals";
    }

    @GetMapping("/editvehicle/{id}")
    String editVehicle(@PathVariable("id")int id,Model v)
    {
        v.addAttribute("editvehicle",vs.getVehicle(id));
        return "editvehicle";
    }

    @PostMapping("/editvehicle")
    String editVehicle(@ModelAttribute("m")Vehical v)
    {
        vs.updateVehicle(v);
        return "redirect:/vehicals";
    }

    @GetMapping("/deletevehicle/{id}")
    String deleteVehicle(@PathVariable("id")int id)
    {
        vs.deleteVeh(id);
        return "redirect:/vehicals";
    }

    @GetMapping("/productvisual")
    String proVisual()
    {
        return "productvisualization";
    }
}

