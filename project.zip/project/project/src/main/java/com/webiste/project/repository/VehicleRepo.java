package com.webiste.project.repository;

import com.webiste.project.model.Vehical;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleRepo extends JpaRepository<Vehical,Integer> {
}
