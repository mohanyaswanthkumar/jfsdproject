package com.webiste.project.repository;

import com.webiste.project.model.Service;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ServiceRepo extends JpaRepository<Service,Integer> {
    List<Service> findByUserid(int userid);
}
