package com.webiste.project.model;

import jakarta.persistence.*;
import org.springframework.data.repository.cdi.Eager;

@Entity
@Table(name = "cart")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int cid;
    int vid;

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    int id;
    String vname;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    String vimage;
    long vprice;
    int quantity=1;
    public int getVid() {
        return vid;
    }
    public void setVid(int vid) {
        this.vid = vid;
    }
    public String getVname() {
        return vname;
    }
    public void setVname(String vname) {
        this.vname = vname;
    }
    public String getVimage() {
        return vimage;
    }
    public void setVimage(String vimage) {
        this.vimage = vimage;
    }
    public long getVprice() {
        return vprice;
    }
    public void setVprice(long vprice) {
        this.vprice = vprice;
    }
    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    @Override
    public String toString() {
        return "Cart [vid=" + vid + ", vname=" + vname + ", vimage=" + vimage + ", vprice=" + vprice + ", quantity="
                + quantity + "]";
    }

}

