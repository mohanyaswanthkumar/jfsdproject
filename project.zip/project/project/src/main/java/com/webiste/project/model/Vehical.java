package com.webiste.project.model;

import jakarta.persistence.*;

@Entity
@Table(name = "vehical")
public class Vehical {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int vid;
    String vname,vdescription,vbrand,vcolour,vimage;
    int vprice;

    public String getVname() {
        return vname;
    }
    public void setVname(String vname) {
        this.vname = vname;
    }
    public String getVdescription() {
        return vdescription;
    }
    public void setVdescription(String vdescription) {
        this.vdescription = vdescription;
    }
    public String getVbrand() {
        return vbrand;
    }
    public void setVbrand(String vbrand) {
        this.vbrand = vbrand;
    }
    public String getVcolour() {
        return vcolour;
    }
    public void setVcolour(String vcolour) {
        this.vcolour = vcolour;
    }
    public String getVimage() {
        return vimage;
    }
    public void setVimage(String vimage) {
        this.vimage = vimage;
    }
    public int getVprice() {
        return vprice;
    }
    public void setVprice(int vprice) {
        this.vprice = vprice;
    }
    public int getVid() {
        return vid;
    }
    public void setVid(int vid) {
        this.vid = vid;
    }

    @Override
    public String toString() {
        return "Vehical{" +
                "vid=" + vid +
                ", vname='" + vname + '\'' +
                ", vdescription='" + vdescription + '\'' +
                ", vbrand='" + vbrand + '\'' +
                ", vcolour='" + vcolour + '\'' +
                ", vimage='" + vimage + '\'' +
                ", vprice=" + vprice +
                '}';
    }
}

