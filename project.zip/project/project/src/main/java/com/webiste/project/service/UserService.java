package com.webiste.project.service;

import com.webiste.project.model.User;
import com.webiste.project.repository.UserRepo;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
public class UserService {

    @Autowired
    private UserRepo repo;

    @Autowired
    JavaMailSender mail;

//    @org.springframework.beans.factory.annotation.Autowired(required=true)
    private BCryptPasswordEncoder passwordEncoder;
    public void addUser(User det) {
        try {
//                    SimpleMailMessage smm=new SimpleMailMessage();
//                    smm.setFrom("bitramohanyaswanthkumar@gmail.com");
//                    smm.setTo(email);
//                    smm.setSubject("Login");
//                    smm.setText("You have logged in to your account Successfully");
//                    mail.send(smm);
            MimeMessage msg=mail.createMimeMessage();
            MimeMessageHelper helper=new MimeMessageHelper(msg,true);
            helper.setFrom("bitramohanyaswanthkumar@gmail.com");
            helper.setTo(det.getEmail());
            helper.setText("You are registered succesfully and you're email is "+det.getEmail()+"and your password is :"+det.getPassword());
            helper.setSubject("Registration");
            mail.send(msg);
            System.out.println("Mail send successfully");
        }
        catch(Exception e)
        {
            System.out.println("not send"+e);
        }
        passwordEncoder=new BCryptPasswordEncoder();
        det.setPassword(passwordEncoder.encode(det.getPassword()));
        repo.save(det);
    }

    public void updateProf(User up) {

        repo.save(up);
    }

    public void deleteUser(int id) {

        repo.deleteById(id);
    }

    public User authenticateUser(String email, String password) {

        User u=repo.findByEmail(email);
        System.out.println(u.getPassword());
        passwordEncoder=new BCryptPasswordEncoder();
        System.out.println(passwordEncoder.encode(password));
        if(u!=null)
        {
            if(passwordEncoder.matches(password, u.getPassword()))
            {
                try {
//                    SimpleMailMessage smm=new SimpleMailMessage();
//                    smm.setFrom("bitramohanyaswanthkumar@gmail.com");
//                    smm.setTo(email);
//                    smm.setSubject("Login");
//                    smm.setText("You have logged in to your account Successfully");
//                    mail.send(smm);
//                    MimeMessage msg=mail.createMimeMessage();
//                    MimeMessageHelper helper=new MimeMessageHelper(msg,true);
//                    helper.setFrom("bitramohanyaswanthkumar@gmail.com");
//                    helper.setTo(email);
//                    helper.setText("You are Logged in Successfully");
//                    helper.setSubject("Login");
//                    mail.send(msg);
                    System.out.println("Mail send successfully");
                }
                catch(Exception e)
                {
                    System.out.println("not send"+e);
                }
                return u;
            }
            return null;
        }
        return null;
    }

//    public void uploadimg(Blob img, int id) {
//        User u=repo.findById(id).orElse(null);
//        if(u!=null)
//        {
//            u.setImage(img);
//        }
//
//    }

    public List<User> allusers() {

        return repo.findAll();
    }

    public void addUserbyAdmin(User u) {
        repo.save(u);

    }

    public int updatePass(String password,String confirmpassword, String email) {
        User u=repo.findByEmail(email);
        passwordEncoder=new BCryptPasswordEncoder();
        System.out.println(u);
        if(passwordEncoder.matches(password, u.getPassword()))
        {
            u.setPassword(passwordEncoder.encode(confirmpassword));
            repo.save(u);
            return 1;
        }
        return 0;
    }

    public void addnewpass(String password,String confirmpassword, String email)
    {
        passwordEncoder=new BCryptPasswordEncoder();
        User u=repo.findByEmail(email);
        u.setPassword(passwordEncoder.encode(confirmpassword));
        repo.save(u);
    }


//	public List<User> getUser() {
//
//		return repo.findAll();
//	}

    public List<User> getAllUsers() {
        return repo.findAll();
    }

    public int emailverify(String email)
    {
        User u=repo.findByEmail(email);
        System.out.println(u.getEmail());
        if(u!=null)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    public int otp_send(String email)
    {
            Random r=new Random();
            int minRange = 1000;
            int maxRange = 9999;
            int randomNumber2 = r.nextInt(maxRange - minRange + 1) + minRange;
            System.out.println(randomNumber2);
        try {
            MimeMessage msg=mail.createMimeMessage();
            MimeMessageHelper helper=new MimeMessageHelper(msg,true);
            helper.setFrom("bitramohanyaswanthkumar@gmail.com");
            helper.setTo(email);
            helper.setText("OTP for Email Verification is :-"+randomNumber2);
            helper.setSubject("OTP Verification");
            mail.send(msg);
            System.out.println("Mail send successfully");
        }
        catch(Exception e)
        {
            System.out.println("not send"+e);
        }
            return randomNumber2;

    }

}

