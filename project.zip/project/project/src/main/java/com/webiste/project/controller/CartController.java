package com.webiste.project.controller;

import com.webiste.project.model.Cart;
import com.webiste.project.model.User;
import com.webiste.project.model.Vehical;
import com.webiste.project.service.CartService;
import com.webiste.project.service.VehicleService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Controller
public class CartController {

    @Autowired
    CartService cao;
    @Autowired
    VehicleService vao;
    @GetMapping("/mycart")
    String myCart(HttpSession s, Model m)
    {
        User u=(User)s.getAttribute("user");
        List<Cart> l=cao.viewcart(u.getId());
        m.addAttribute("cart", l);
        return "cart";
    }

    @GetMapping("/cart/{id}")
    String cart(@PathVariable("id")int id, HttpSession session)
    {
        User u=(User)session.getAttribute("user");
        if(u==null) {
            return "redirect:/login";
        }
        Vehical veh=vao.getVehicle(id);
        Cart c=new Cart();
        c.setVid(veh.getVid());
        c.setVimage(veh.getVimage());
        c.setVname(veh.getVname());
        c.setVprice(veh.getVprice());
        c.setQuantity(1);
        c.setId(u.getId());
        cao.addCart(c);
        return "redirect:/vehicals";
    }
    @GetMapping("/removecart/{cid}")
    String deleteCart(@PathVariable("cid")int cid)
    {
        cao.removeCart(cid);
        System.out.println(cid);
        return "redirect:/mycart";
    }

    @GetMapping("/buy")
    String buyPro()
    {
        return "payment";
    }

}

