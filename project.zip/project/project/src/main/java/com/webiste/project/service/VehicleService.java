package com.webiste.project.service;

import com.webiste.project.model.Vehical;
import com.webiste.project.repository.VehicleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleService {

    @Autowired
    VehicleRepo service;
    public List<Vehical> findAll() {
        return service.findAll();
    }

    public Vehical getVehicle(int id) {
        return service.findById(id).orElse(null);
    }

    public void addVehical(Vehical v) {
        service.save(v);
    }

    public void updateVehicle(Vehical v) {
        service.save(v);
    }

    public void deleteVeh(int id) {
        service.deleteById(id);
    }
}
