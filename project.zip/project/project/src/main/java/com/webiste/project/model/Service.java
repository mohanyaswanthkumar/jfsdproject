package com.webiste.project.model;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "service")
public class Service {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int id;
    String servicetype;
    String shortdescription;
    String model;
    Date date;
    int userid;
    String status;

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getServicetype() {
        return servicetype;
    }
    public void setServicetype(String servicetype) {
        this.servicetype = servicetype;
    }
    public String getShortdescription() {
        return shortdescription;
    }
    public void setShortdescription(String shortdescription) {
        this.shortdescription = shortdescription;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(java.util.Date d) {
        this.date = (Date) d;
    }
    public int getUserid() {
        return userid;
    }
    public void setUserid(int userid) {
        this.userid = userid;
    }
    @Override
    public String toString() {
        return "Service [id=" + id + ", servicetype=" + servicetype + ", shortdescription=" + shortdescription
                + ", date=" + date + ", userid=" + userid + "]";
    }

}
