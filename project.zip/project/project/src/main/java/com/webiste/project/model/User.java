package com.webiste.project.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name="users")
@AllArgsConstructor
@ToString
@NoArgsConstructor
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int id;
    String name;
    String username;
    String email=null;
    String password;
    @Transient
    String confirmpassword;
    long mobile;
    @Transient
    String gender;
    String roles="user";
    String image;
    @Transient
    String realCaptch;
    @Transient
    String captcha;
    @Transient
    String hiddenCaptcha;

    public String getRealCaptch() {
        return realCaptch;
    }

    public void setRealCaptch(String realCaptch) {
        this.realCaptch = realCaptch;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    public String getHiddenCaptcha() {
        return hiddenCaptcha;
    }

    public void setHiddenCaptcha(String hiddenCaptcha) {
        this.hiddenCaptcha = hiddenCaptcha;
    }

    //    public byte[] getImage() {
//        return image;
//    }
//
//    public void setImage(byte[] image) {
//        this.image = image;
//    }
//
//    public String getRoles() {
//        return roles;
//    }
//    public void setRoles(String roles) {
//        this.roles = roles;
//    }
//    public int getId() {
//        return id;
//    }
//    public void setId(int id) {
//        this.id = id;
//    }
//    public String getName() {
//        return name;
//    }
//    public void setName(String name) {
//        this.name = name;
//    }
//    public String getEmail() {
//        return email;
//    }
//    public void setEmail(String email) {
//        this.email = email;
//    }
//    public String getPassword() {
//        return password;
//    }
//    public void setPassword(String password) {
//        this.password = password;
//    }
//    public String getConfirmpassword() {
//        return confirmpassword;
//    }
//    public void setConfirmpassword(String confirmpassword) {
//        this.confirmpassword = confirmpassword;
//    }
//    public long getMobile() {
//        return mobile;
//    }
//    public void setMobile(long mobile) {
//        this.mobile = mobile;
//    }
//    public String getUsername() {
//        return username;
//    }
//    public void setUsername(String username) {
//        this.username = username;
//    }
//
//    public String getGender() {
//        return gender;
//    }
//    public void setGender(String gender) {
//        this.gender = gender;
//    }
//    @Override
//    public String toString() {
//        return "User [id=" + id + ", name=" + name + ", username=" + username + ", email=" + email + ", password="
//                + password + ", confirmpassword=" + confirmpassword + ", mobile=" + mobile + ", gender=" + gender
//                + ", roles=" + roles + ", image=" + image + "]";
//    }

}

