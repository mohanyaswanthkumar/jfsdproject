package com.webiste.project.controller;

import cn.apiclub.captcha.Captcha;
import com.webiste.project.model.User;
import com.webiste.project.service.CaptchaService;
import com.webiste.project.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;

@Controller
public class UserController {
    @Autowired
    UserService service;

    @GetMapping("/register")
    String register(Model det) {
        det.addAttribute("details", new User());
        return "register";
    }

    @PostMapping("/updateprofile")
    String updateProfile(@ModelAttribute("pupdate") User up, HttpSession s) {
        User x = (User) s.getAttribute("user");
        System.out.println(x);
        x.setEmail(up.getEmail());
        x.setMobile(up.getMobile());
        x.setName(up.getName());
        x.setUsername(up.getUsername());
        x.setImage(up.getImage());
        x.setId(up.getId());
        s.setAttribute("user", x);
        service.updateProf(up);
        //System.out.println(up);
        return "redirect:/profile";
    }

    @GetMapping("/deleteuser/{id}")
    String deleteProfile(@PathVariable("id") int id) {
        service.deleteUser(id);
        //return "redirect:/allusers";
        return "success done";
    }

    @PostMapping("/register")
    String register(@ModelAttribute("det") User det) {
        service.addUser(det);
        //System.out.print(det);
        return "redirect:/login";
    }

    @GetMapping("/login")
    String login(Model det) {
        User u1 = new User();
        Captcha captcha = CaptchaService.createCaptcha(200, 70);
        u1.setRealCaptch(CaptchaService.encodeCaptcha(captcha));
        u1.setHiddenCaptcha(captcha.getAnswer());
        u1.setCaptcha("");
        det.addAttribute("det",u1);
        System.out.println(u1.getRealCaptch()+""+u1.getHiddenCaptcha()+u1.getCaptcha());
        return "login";
    }

    @PostMapping("/login")
    String login(@ModelAttribute("det") User det, HttpSession users, Model m) {
        String email = det.getEmail();
        String password = det.getPassword();
        //System.out.println(email+""+password);
        User user = service.authenticateUser(email, password);
        if (user != null && det.getHiddenCaptcha().equalsIgnoreCase(det.getCaptcha())) {
            users.setAttribute("user", user);
            System.out.println(det.getRealCaptch()+""+det.getHiddenCaptcha()+det.getCaptcha());
            return "redirect:/";
        } else {
            //m.addAttribute("message", "invalid credentials");
            return "redirect:/login";
        }
    }

    @GetMapping("/")
    String home(Model m) {
        return "home";
    }



    @GetMapping("/profile")
    String profile(Model m,HttpSession s) {
        User u= (User) s.getAttribute("user");
        System.out.println(u.getEmail());
        if(u!=null)
        {
            m.addAttribute("users",u);
            return "profile";
        }
        else
        {
            return "redirect:/";
        }
    }

    @GetMapping("/logout")
    String logout(HttpSession users) {
        users.removeAttribute("user");
        return "redirect:/";
    }

    @GetMapping("/allusers")
    String allusers(Model m,HttpSession s) {
        User u=(User)s.getAttribute("user");
        if(u.getRoles().equals("admin")) {
            List<User> ls = service.allusers();
            //System.out.println(ls);
            m.addAttribute("allusers", ls);
            return "showusers";
        }
        else
        {
            return "redirect:/";
        }
    }

    @GetMapping("/adduserbyadmin")
    String adduserbyAdmin(Model m) {
        m.addAttribute("newuser", new User());
        return "adduserbyadmin";
    }

    @PostMapping("/adduserbyadmin")
    String adduserbyAdmin(@ModelAttribute("newuseradd") User u,HttpSession s) {
        User x = (User) s.getAttribute("user");
        if (x.getRoles().equals("admin")) {
            service.addUserbyAdmin(u);
            return "redirect:/allusers";
        } else {
            return "redirect:/";
        }
    }
    @GetMapping("/updatepassword")
    String updatePassword(Model m) {
        return "updatepassword";
    }

    @PostMapping("/updatepassword")
    String updatePassword(@ModelAttribute("newpass") User newpass, HttpSession s) {
        User x = (User) s.getAttribute("user");
        int v=service.updatePass(newpass.getPassword(),newpass.getConfirmpassword(), x.getEmail());
        if(v==0)
        {
            return "redirect:/updatepassword";
        }
        return "redirect:/profile";
    }

    @GetMapping("/forgot")
    String forgot_password(Model m)
    {
        return "forgotpassword";
    }
    @PostMapping("/forgot")
    String forgot_password(@ModelAttribute("u")User u,HttpSession m)
    {
        String email=u.getEmail();
        int value=service.emailverify(email);
        m.setAttribute("email",email);
        System.out.println(email);
        if(value==0)
        {
            return "redirect:/forgot";
        }
        return "redirect:/otp";
    }
    @GetMapping("/otp")
    String enterotp(Model m,HttpSession u)
    {
        m.addAttribute("email",u.getAttribute("email"));
        int otp=service.otp_send((String) u.getAttribute("email"));
        u.setAttribute("otp",otp);
        return "enterotp";
    }
    @PostMapping("/otp")
    String enterotp(@RequestParam("otp1")int otp1,HttpSession s)
    {
        int otp= (int) s.getAttribute("otp");
        if(otp==otp1)
        {
            return "redirect:/setpass";
        }
        return "redirect:/otp";
    }

    @GetMapping("/setpass")
    String createpassword(Model m)
    {
        return "createpassword";
    }
    @PostMapping("/setpass")
    String createpassword(@RequestParam("password") String password,@RequestParam("confirmPassword")String cpassword,HttpSession u)
    {
        System.out.println(password+" "+cpassword);
        service.addnewpass(password,cpassword, (String) u.getAttribute("email"));
        return "redirect:/login";
    }

//    @PostMapping("/uploadimg")
//    String upload_image(@RequestParam("img")MultipartFile file,HttpSession s) throws SQLException, IOException {
//            byte[] bytes=file.getBytes();
//            Blob b=new SerialBlob(bytes);
//            User u=(User)s.getAttribute("user");
//            u.setImage(b);
//            service.updateProf(u);
//            return "redirect:/profile";
//    }

    @GetMapping("/profilenavbar")
    String profilenavbar(Model m,HttpSession s) {
        User u=(User)s.getAttribute("user");
//        byte[] imageData = u.getImage();
//        String image = DatatypeConverter.printHexBinary(u.getImage());
//        MultipartFile s=Base64.getDecoder().decode(u.getImage());
        m.addAttribute("image",u.getImage());
        return "profilenavBar";
    }
@PostMapping("/uploadimg")
String upload_image(@RequestParam("img") MultipartFile file, HttpSession session) throws SQLException, IOException {
    User user = (User) session.getAttribute("user");
    String s= Base64.getEncoder().encodeToString(file.getBytes());
    System.out.println(s);
        user.setImage(s);
        service.updateProf(user);
    return "redirect:/profile";
}

}
