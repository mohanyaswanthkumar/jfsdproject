package com.webiste.project.repository;

import com.webiste.project.model.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CartRepo extends JpaRepository<Cart,Integer> {


    List<Cart> findAllById(int id);

    void deleteByCid(int cid);
}
