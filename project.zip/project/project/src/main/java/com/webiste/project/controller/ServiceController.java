package com.webiste.project.controller;

import com.webiste.project.model.Service;
import com.webiste.project.model.User;
import com.webiste.project.service.RequestService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@Controller
public class ServiceController {
    @Autowired
    RequestService req;

    @GetMapping("/myservice")
    String myservicesHistory(Model m, HttpSession s)
    {
        User u=(User)s.getAttribute("user");
        m.addAttribute("myservices", req.getUserRequest(u.getId()));
        return "services";
    }

    @GetMapping("allservice")
    String allserviceHistory(Model m)
    {
        m.addAttribute("allservices", req.getAllServices());
        return "allservices";
    }

    @GetMapping("/reqser")
    String requestForm(Model m)
    {
        m.addAttribute("service-form", new Service());
        return "raiserequest";
    }

    @PostMapping("/addrequest")
    String requestSubmit(@ModelAttribute("reqform")Service s, HttpSession x)
    {
        Date d;
        User u=(User)x.getAttribute("user");
        s.setUserid(u.getId());
        s.setStatus("pending");
        req.submitRequest(s);
        return "redirect:/myservice";
    }
}
