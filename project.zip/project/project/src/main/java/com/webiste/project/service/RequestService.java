package com.webiste.project.service;

import com.webiste.project.repository.ServiceRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RequestService {

    @Autowired
    ServiceRepo repo;
    public List<com.webiste.project.model.Service> getUserRequest(int userid) {
        return (List<com.webiste.project.model.Service>) repo.findByUserid(userid);
    }

    public List<com.webiste.project.model.Service> getAllServices() {
            return repo.findAll();
    }

    public void submitRequest(com.webiste.project.model.Service s) {
        repo.save(s);
    }
}
